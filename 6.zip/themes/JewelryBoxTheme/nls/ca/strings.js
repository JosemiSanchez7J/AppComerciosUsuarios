define({
  "_themeLabel": "Tema Estoig",
  "_layout_default": "Disseny per defecte",
  "_layout_layout1": "Disseny 1",
  "emptyDocablePanelTip": "Feu clic al botó + de la pestanya Widget per afegir un widget. "
});