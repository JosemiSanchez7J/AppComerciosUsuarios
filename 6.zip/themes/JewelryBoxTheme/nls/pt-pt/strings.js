define({
  "_themeLabel": "Tema Caixa de Joias",
  "_layout_default": "Layout predefinido",
  "_layout_layout1": "Layout 1",
  "emptyDocablePanelTip": "Clique no botão + no separador Widget para adicionar um widget. "
});