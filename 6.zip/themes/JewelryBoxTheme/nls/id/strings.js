define({
  "_themeLabel": "Tema Jewelry Box",
  "_layout_default": "Tata letak default",
  "_layout_layout1": "Tata Letak 1",
  "emptyDocablePanelTip": "Klik tombol + di tab Widget untuk menambahkan sebuah widget. "
});