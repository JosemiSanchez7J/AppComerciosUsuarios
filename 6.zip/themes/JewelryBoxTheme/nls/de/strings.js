define({
  "_themeLabel": "Jewelry Box-Design",
  "_layout_default": "Standard-Layout",
  "_layout_layout1": "Layout 1",
  "emptyDocablePanelTip": "Klicken Sie auf der Registerkarte \"Widget\" auf die Schaltfläche \"+\", um ein Widget hinzuzufügen. "
});