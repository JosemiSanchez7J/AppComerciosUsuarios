define({
  "_themeLabel": "Skrinjica",
  "_layout_default": "Privzeta postavitev",
  "_layout_layout1": "Postavitev 1",
  "emptyDocablePanelTip": "Kliknite gumb + v zavihku Pripomočkov za dodajanje pripomočka. "
});